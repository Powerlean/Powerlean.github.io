from flask import Flask, render_template, request, send_file, jsonify, Response, stream_with_context, url_for, send_from_directory
from paper_generator_zhipu import PaperGenerator
import os
import time
import json
import logging

# 配置日志
logging.basicConfig(
    filename='app.log',
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# 同时输出到控制台
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

logger.info("=== 服务器启动 ===")

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 限制上传大小为16MB

# 配置文件保存目录
UPLOAD_FOLDER = 'papers'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
    logger.info(f"创建上传目录: {UPLOAD_FOLDER}")

# 从环境变量获取 API key
api_key = os.environ.get('ZHIPU_API_KEY')

def generate_paper_function(topic, education_level, major, word_count):
    """生成论文并返回文件路径"""
    logger.info("=== 开始生成论文 ===")
    logger.info(f"参数: topic={topic}, education_level={education_level}, major={major}, word_count={word_count}")
    
    try:
        # 初始化生成器
        generator = PaperGenerator(api_key)
        
        # 生成论文
        paper = generator.generate_full_paper(
            topic,
            education_level,
            major,
            int(word_count) if word_count else None
        )
        
        # 保存文件
        filename = f"论文_{topic}_{education_level}_{major}_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write("摘要\n")
            f.write(paper["abstract"])
            f.write("\n\n")
            f.write("正文\n")
            f.write(paper["content"])
            f.write("\n\n")
            f.write("参考文献\n")
            f.write(paper["references"])
            f.write("\n\n")
                   
        logger.info(f"论文已保存到: {filepath}")
        return filepath
        
    except Exception as e:
        logger.error(f"论文生成失败: {str(e)}", exc_info=True)
        raise

@app.route('/')
def index():
    return render_template('landing.html')

@app.route('/generator')
def generator():
    return render_template('index.html')

@app.route('/overview')
def overview():
    return render_template('overview.html')

@app.route('/generate', methods=['POST'])
def generate_paper():
    try:
        title = request.form.get('title')
        education = request.form.get('education')
        subject = request.form.get('subject')
        words = request.form.get('words')
        
        # 调用论文生成函数
        file_path = generate_paper_function(title, education, subject, words)
        
        # 读取生成的论文内容
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 解析内容 - 使用更简单的分割方式
        sections = content.split('\n\n')  # 使用两个换行符分割各部分
        paper_content = {
            'abstract': '',
            'content': '',
            'references': ''
        }
        
        current_section = None
        for section in sections:
            if '摘要' in section:
                current_section = 'abstract'
                paper_content['abstract'] = section.replace('摘要\n', '')
            elif '正文' in section:
                current_section = 'content'
                paper_content['content'] = section.replace('正文\n', '')
            elif '参考文献' in section:
                current_section = 'references'
                paper_content['references'] = section.replace('参考文献\n', '')
            elif current_section:  # 如果属于当前section的内容继续
                paper_content[current_section] += '\n' + section
        
        # 只返回下载链接和内容，不自动跳转
        return jsonify({
            'success': True,
            'file_url': url_for('download_paper', filename=os.path.basename(file_path)),
            'content': paper_content
        })
    except Exception as e:
        logger.error(f"论文生成失败: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/download/<path:filename>')
def download_file(filename):
    return send_from_directory('static', filename, 
                             mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                             as_attachment=True)

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"500 error: {error}", exc_info=True)
    return jsonify({'error': '服务器内部错误'}), 500

@app.errorhandler(404)
def not_found_error(error):
    logger.error(f"404 error: {error}")
    return jsonify({'error': '页面未找到'}), 404

@app.route('/health')
def health_check():
    return 'healthy', 200

if __name__ == '__main__':
    logger.info("启动 Flask 服务器...")
    app.run(host='0.0.0.0', port=8000, debug=False) 