from flask import Flask, render_template, request, send_file, jsonify, Response, stream_with_context, url_for, send_from_directory
from paper_generator_zhipu import PaperGenerator
import os
import time
import json
import logging

# 配置日志
logging.basicConfig(
    filename='app.log',
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# 同时输出到控制台
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

logger.info("=== 服务器启动 ===")

app = Flask(__name__)

# 配置文件保存目录
UPLOAD_FOLDER = 'papers'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
    logger.info(f"创建上传目录: {UPLOAD_FOLDER}")

def generate_paper_function(topic, education_level, major, word_count):
    """生成论文并返回文件路径"""
    logger.info("=== 开始生成论文 ===")
    logger.info(f"参数: topic={topic}, education_level={education_level}, major={major}, word_count={word_count}")
    
    try:
        # 初始化生成器
        generator = PaperGenerator("c114237eadb9d323464234e5c0f666eb.8tzOvKqUDeno8QcT")
        
        # 生成论文
        paper = generator.generate_full_paper(
            topic,
            education_level,
            major,
            int(word_count) if word_count else None
        )
        
        # 保存文件
        filename = f"论文_{topic}_{education_level}_{major}_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"题目：{topic}\n")
            f.write(f"学历层次：{education_level}\n")
            f.write(f"专业类型：{major}\n")
            f.write("\n" + "="*50 + "\n\n")
            f.write("【摘要】\n")
            f.write(paper["abstract"])
            f.write("\n\n" + "="*50 + "\n\n")
            f.write("【正文】\n")
            f.write(paper["content"])
            f.write("\n\n" + "="*50 + "\n\n")
            f.write("【参考文献】\n")
            f.write(paper["references"])
            f.write("\n\n" + "="*50 + "\n\n")
            f.write("【质量检查报告】\n")
            f.write(paper["quality_report"])
        
        logger.info(f"论文已保存到: {filepath}")
        return filepath
        
    except Exception as e:
        logger.error(f"论文生成失败: {str(e)}", exc_info=True)
        raise

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_paper():
    try:
        title = request.form.get('title')
        education = request.form.get('education')
        subject = request.form.get('subject')
        words = request.form.get('words')
        
        # 调用论文生成函数
        file_path = generate_paper_function(title, education, subject, words)
        
        return jsonify({
            'success': True,
            'file_url': url_for('download_paper', filename=os.path.basename(file_path))
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/download/<filename>')
def download_paper(filename):
    return send_from_directory('papers', filename)

if __name__ == '__main__':
    logger.info("启动 Flask 服务器...")
    app.run(debug=True) 