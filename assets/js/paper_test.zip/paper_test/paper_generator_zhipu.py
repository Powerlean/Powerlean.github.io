import zhipuai
import time
from typing import Dict, List

class PaperGenerator:
    def __init__(self, api_key: str):
        self.api_key = api_key
        zhipuai.api_key = api_key
        
        # 不同学历层次的提示词模板
        self.education_templates = {
            "专科": "请以专科生水平，注重实用性和案例分析的方式",
            "本科": "请以本科生水平，注重理论基础和研究方法的方式"
        }
        
        # 不同专业的提示词模板
        self.major_templates = {
            "理工": "需要包含数据分析、实验内容和具体技术实现",
            "文科": "需要强调文献综述、理论分析和社会意义",
            "医学": "需要包含临床案例分析、治疗方案和实践经验"
        }
        
        # 添加每种学历层次的默认字数范围
        self.word_count_ranges = {
            "专科": (3000, 5000),
            "本科": (5000, 8000)
        }

    def _call_api(self, messages: List[Dict], retry_count: int = 3) -> str:
        """调用智谱AI API"""
        for attempt in range(retry_count):
            try:
                print(f"API调用尝试 {attempt + 1}/{retry_count}")
                client = zhipuai.ZhipuAI(api_key=self.api_key)
                response = client.chat.completions.create(
                    model="glm-4-flash",
                    messages=messages,
                    temperature=0.7,
                    max_tokens=2000,
                    timeout=60,  # 增加到60秒
                )
                
                if hasattr(response, 'choices') and response.choices:
                    return response.choices[0].message.content
                else:
                    print(f"API响应格式错误: {response}")
                    if attempt < retry_count - 1:
                        print("等待5秒后重试...")
                        time.sleep(5)
                    continue
                    
            except KeyboardInterrupt:
                print("\n用户中断操作")
                return ""
            except Exception as e:
                print(f"调用出错: {str(e)}")
                if attempt < retry_count - 1:
                    print("等待5秒后重试...")
                    time.sleep(5)
                continue
        
        print(f"已达到最大重试次数 ({retry_count}次)，操作失败")
        return ""

    def generate_outline(self, topic: str, education_level: str, major: str) -> str:
        """生成论文大纲"""
        prompt = f"{self.education_templates[education_level]}，{self.major_templates[major]}，生成一篇关于\"{topic}\"的论文大纲，包括章节标题和每章节的主要内容点。"
        
        messages = [
            {"role": "system", "content": "你是一个专业的论文写作助手"},
            {"role": "user", "content": prompt}
        ]
        
        return self._call_api(messages)

    def clean_text(self, text: str) -> str:
        """清理文本中的markdown标记和其他不必要的格式"""
        # 替换常见的markdown标记
        replacements = {
            '# ': '',
            '## ': '',
            '### ': '',
            '#### ': '',
            '- ': '',
            '* ': '',
            '```': '',
            '`': '',
            '**': '',
            '__': '',
            '> ': '',
            '>>': '',
        }
        
        cleaned_text = text
        for mark, replace_with in replacements.items():
            cleaned_text = cleaned_text.replace(mark, replace_with)
        
        # 清理多余的空行
        cleaned_text = '\n'.join(line.strip() for line in cleaned_text.split('\n') if line.strip())
        
        return cleaned_text

    def generate_chapter(self, outline: str, chapter_title: str, education_level: str, major: str, target_length: int) -> str:
        """生成具体章节内容"""
        try:
            print("准备章节内容生成...")
            prompt = (
                f"{self.education_templates[education_level]}，{self.major_templates[major]}，"
                f"根据大纲：{outline}，详细展开\"{chapter_title}\"这一章节的内容。"
                f"严格控制在{target_length}字以内。注意：\n"
                f"1. 避免过多使用'首先'、'其次'、'然后'、'此外'等明显的逻辑连接词\n"
                f"2. 使用更自然的学术写作风格\n"
                f"3. 段落之间要有自然的过渡\n"
                f"4. 多用专业术语和具体论述\n"
                f"5. 避免简单的罗列和堆砌\n"
                f"请用流畅自然的学术语言输出纯文本格式。"
            )
            
            print(f"提示词长度: {len(prompt)} 字符")
            
            messages = [
                {
                    "role": "system", 
                    "content": (
                        "你是一个专业的论文写作助手，擅长用自然流畅的学术语言写作。"
                        "避免使用机械的逻辑连接词，而是通过内容的自然递进来展现文章逻辑。"
                        "注重用专业的学术表达方式。"
                    )
                },
                {"role": "user", "content": prompt}
            ]
            
            # 直接调用API并返回结果
            content = self._call_api(messages)
            
            if not content:
                print(f"生成章节 '{chapter_title}' 失败")
                return ""
            
            # 清理内容中的markdown标记
            content = self.clean_text(content)
            
            # 检查字数并在必要时截断
            if len(content) > target_length * 1.1:
                print(f"警告: 内容超出目标字数 ({len(content)}/{target_length})，进行截断...")
                sentences = content.split('。')
                truncated_content = ''
                current_length = 0
                
                for sentence in sentences:
                    if current_length + len(sentence) + 1 <= target_length * 1.1:
                        truncated_content += sentence + '。'
                        current_length = len(truncated_content)
                    else:
                        break
                
                content = truncated_content
                print(f"截断后字数: {len(content)}")
            
            return content
            
        except Exception as e:
            print(f"生成章节时出错: {str(e)}")
            return ""

    def generate_references(self, content: str, major: str) -> str:
        """生成参考文献"""
        prompt = f"根据论文内容：{content[:1000]}...，生成相关的参考文献列表，要求符合{major}专业特点，包含近五年的文献。"
        
        messages = [
            {"role": "system", "content": "你是一个专业的论文写作助手"},
            {"role": "user", "content": prompt}
        ]
        
        return self._call_api(messages)

    def generate_abstract(self, content: str, education_level: str) -> str:
        """生成摘要"""
        prompt = f"根据论文内容：{content[:1500]}...，{self.education_templates[education_level]}生成论文摘要和关键词。"
        
        messages = [
            {"role": "system", "content": "你是一个专业的论文写作助手"},
            {"role": "user", "content": prompt}
        ]
        
        return self._call_api(messages)

    def quality_check(self, content: str, education_level: str, major: str) -> str:
        """质量检查"""
        prompt = f"请检查以下论文内容的学术性、逻辑性和专业术语使用是否符合{education_level}水平和{major}专业特点：{content[:2000]}..."
        
        messages = [
            {"role": "system", "content": "你是一个专业的论文审核专家"},
            {"role": "user", "content": prompt}
        ]
        
        return self._call_api(messages)

    def parse_outline(self, outline: str) -> List[str]:
        """解析大纲内容，提取实际的章节标题"""
        lines = [line.strip() for line in outline.split('\n') if line.strip()]
        chapters = []
        
        for line in lines:
            # 跳过"论文大纲："等非章节标题
            if line.startswith('论文大纲') or line.startswith('目录') or ':' in line:
                continue
            # 移除��号（如"1."、"一、"等）
            cleaned_line = ' '.join(line.split()[1:] if line.split() and line.split()[0].rstrip('.、）)') else line)
            if cleaned_line:
                chapters.append(cleaned_line)
                
        return chapters

    def generate_full_paper(self, topic: str, education_level: str, major: str, total_words: int = None) -> Dict[str, str]:
        """生成完整论文"""
        try:
            # 如果未指定字数，使用默认范围的中间值
            if total_words is None:
                min_words, max_words = self.word_count_ranges[education_level]
                total_words = (min_words + max_words) // 2
            
            # 预留一些字数给摘要和参考文献
            reserved_words = total_words * 0.15  # 预留15%的字数
            chapter_total_words = int(total_words * 0.85)  # 正文使用85%的字数
            
            print(f"目标论文总字数: {total_words}")
            print(f"正文目标字数: {chapter_total_words}")
            
            # 生成大纲
            print("开始生成论文大纲...")
            outline = self.generate_outline(topic, education_level, major)
            outline = self.clean_text(outline)  # 清理大纲中的markdown标记
            if not outline:
                raise Exception("生成大纲失败")
            
            print("\n获取到的大纲内容:")
            print(outline)
            
            # 解析章节
            chapters = self.parse_outline(outline)
            if not chapters:
                raise Exception("无法从大纲中提取有效的章节标题")
            
            chapter_count = len(chapters)
            print(f"\n识别到 {chapter_count} 个章节:")
            for i, chapter in enumerate(chapters, 1):
                print(f"{i}. {chapter}")
            
            # 计算每个章节的目标字数
            words_per_chapter = chapter_total_words // chapter_count
            print(f"每章节平均目标字数: {words_per_chapter}")
            
            full_content = ""
            current_total_words = 0
            
            # 生成各章节内容
            for index, chapter in enumerate(chapters, 1):
                try:
                    print(f"\n[{index}/{chapter_count}] 正在生成章节: {chapter}")
                    
                    # 动态调整剩余章节的字数
                    remaining_chapters = chapter_count - index + 1
                    remaining_words = chapter_total_words - current_total_words
                    target_chapter_length = remaining_words // remaining_chapters
                    
                    print(f"本章节目标字数: {target_chapter_length}")
                    
                    chapter_content = self.generate_chapter(
                        outline, chapter, education_level, major, target_chapter_length
                    )
                    
                    if chapter_content:
                        chapter_words = len(chapter_content)
                        current_total_words += chapter_words
                        print(f"章节 '{chapter}' 生成成功 ({chapter_words} 字)")
                        print(f"当前总字数: {current_total_words}/{chapter_total_words}")
                        full_content += f"{chapter}\n{chapter_content}\n\n"
                    else:
                        print(f"警告: 章节 '{chapter}' 生成内容为空")
                        
                except Exception as e:
                    print(f"生成章节 '{chapter}' 时出错: {str(e)}")
                    print("跳过当前章节，继续生成下一章节...")
                    continue
            
            if not full_content:
                raise Exception("所有章节生成均失败")
            
            # 生成其他部分
            print("\n生成参考文献...")
            references = self.generate_references(full_content, major)
            references = self.clean_text(references)
            
            print("\n生成摘要...")
            abstract = self.generate_abstract(full_content, education_level)
            abstract = self.clean_text(abstract)
            
            print("\n进行质量检查...")
            quality_report = self.quality_check(full_content, education_level, major)
            quality_report = self.clean_text(quality_report)
            
            return {
                "outline": outline,
                "content": full_content,
                "abstract": abstract,
                "references": references,
                "quality_report": quality_report
            }
            
        except Exception as e:
            print(f"\n生成论文过程出错: {str(e)}")
            return {
                "outline": "",
                "content": "",
                "abstract": "",
                "references": "",
                "quality_report": f"生成失败: {str(e)}"
            }

def save_paper_to_file(paper: Dict[str, str], topic: str, education_level: str, major: str) -> str:
    """将论文保存到文件"""
    try:
        # 生成文件名，使用主题、学历和专业类型
        filename = f"论文_{topic}_{education_level}_{major}_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        
        with open(filename, 'w', encoding='utf-8') as f:
            # 写入基本信息
            f.write(f"题目：{topic}\n")
            f.write(f"学历层次：{education_level}\n")
            f.write(f"专业类型：{major}\n")
            f.write("\n" + "="*50 + "\n\n")
            
            # 写入摘要
            f.write("【摘要】\n")
            f.write(paper["abstract"])
            f.write("\n\n" + "="*50 + "\n\n")
            
            # 写入正文
            f.write("【正文】\n")
            f.write(paper["content"])
            f.write("\n\n" + "="*50 + "\n\n")
            
            # 写入参考文献
            f.write("【参考文献】\n")
            f.write(paper["references"])
            f.write("\n\n" + "="*50 + "\n\n")
            
            # 写入质量报告
            f.write("【质量检查报告】\n")
            f.write(paper["quality_report"])
            
        return filename
    except Exception as e:
        print(f"保存文件时出错: {str(e)}")
        return ""

def main():
    try:
        api_key = "c114237eadb9d323464234e5c0f666eb.8tzOvKqUDeno8QcT"
        generator = PaperGenerator(api_key)
        
        print("请输入论文信息:")
        topic = input("论文主题: ")
        education_level = input("学历层次（专科/本科）: ")
        major = input("专业类型（理工/文科/医学）: ")
        
        # 添加字数输入
        word_count_input = input("期望论文字数(直接回车使用默认字数): ")
        total_words = int(word_count_input) if word_count_input.strip() else None
        
        if total_words is not None:
            min_words, max_words = generator.word_count_ranges[education_level]
            if total_words < min_words or total_words > max_words * 1.5:
                print(f"警告: 输入的字数 {total_words} 超出{education_level}论文的常规范围 ({min_words}-{max_words})")
                confirm = input("是否继续？(y/n): ")
                if confirm.lower() != 'y':
                    return
        
        paper = generator.generate_full_paper(topic, education_level, major, total_words)
        
        if any(paper.values()):
            print("\n论文生成完成")
            
            # 保存到文件
            filename = save_paper_to_file(paper, topic, education_level, major)
            if filename:
                print(f"\n论文已保存到文件: {filename}")
            
            # 是否在控制台显示内容
            show_content = input("\n是否在控制台显示论文内容？(y/n): ")
            if show_content.lower() == 'y':
                for key, value in paper.items():
                    print(f"\n{key}:")
                    print(value)
        else:
            print("生成论文失败，请检查错误信息")
            
    except Exception as e:
        print(f"程序运行错误: {str(e)}")

if __name__ == "__main__":
    main() 