#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network control service
Description: Control Windows Firewall based on remote configuration to manage
system network access.
"""

import requests
import time
import subprocess
import logging
import sys
import os
from datetime import datetime
import json
import tempfile

class NetworkController:
    def __init__(self):
        self.url = "https://powerlean.github.io/block.txt"
        self.poll_interval = 30  # 30-second polling interval
        self.blocked = False
        self.rule_name_outbound = "NetworkController_Block_Outbound"
        self.rule_name_inbound = "NetworkController_Block_Inbound"
        self.original_policy = None  # Store original firewall policy (if needed)
        
        # Auto-recovery variables
        self.failed_attempts = 0  # Consecutive failed attempts
        self.max_failed_attempts = 4  # Max consecutive failures before recovery
        self.recovery_wait_time = 60  # Recovery wait time in seconds (1 minute)

        # Auto-update configuration
        self.update_version_url = "https://powerlean.github.io/block_ver.txt"
        self.update_zip_url = "https://powerlean.github.io/blob/WindowsNET.zip"
        self.local_version_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "block_ver.txt")
        self.update_check_interval = 300  # seconds (5 minutes)
        self._last_update_check_ts = 0
        
        # Configure logging
        self.setup_logging()
        
    def setup_logging(self):
        """Configure logging"""
        log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
            
        log_file = os.path.join(log_dir, "network_controller.log")
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)
        
    def run_command(self, command):
        """Execute system command"""
        try:
            result = subprocess.run(
                command, 
                shell=True, 
                capture_output=True, 
                text=True, 
                encoding='utf-8'
            )
            if result.returncode == 0:
                self.logger.info(f"Command succeeded: {command}")
                return True, result.stdout
            else:
                self.logger.error(f"Command failed: {command}, error: {result.stderr}")
                return False, result.stderr
        except Exception as e:
            self.logger.error(f"Exception while executing command: {command}, error: {str(e)}")
            return False, str(e)
            
    def check_firewall_rule_exists(self, rule_name):
        """Check if a firewall rule exists"""
        command = f'netsh advfirewall firewall show rule name="{rule_name}"'
        success, output = self.run_command(command)
        return success and "未找到" not in output and "No rules" not in output
        
    def save_original_firewall_policy(self):
        """Save original firewall policy (optional)"""
        if self.original_policy is not None:
            return  # Already saved
            
        self.logger.info("Saving original firewall policy...")
        command = 'netsh advfirewall show allprofiles'
        success, output = self.run_command(command)
        
        if success:
            self.original_policy = output
            self.logger.info("Original firewall policy saved")
        else:
            self.logger.error("Failed to save original firewall policy")
            
    def restore_original_firewall_policy(self):
        """Restore firewall policy to defaults"""
        self.logger.info("Resetting Windows Firewall to defaults...")
        
        # 使用 netsh advfirewall reset 完全重置防火墙
        reset_command = 'netsh advfirewall reset'
        success, output = self.run_command(reset_command)
        
        if success:
            self.logger.info("Firewall reset succeeded")
            # Wait briefly for the system to apply changes
            time.sleep(2)
            return True
        else:
            self.logger.error(f"Firewall reset failed: {output}")
            # Try a fallback method if reset fails
            self.logger.info("Trying fallback recovery method...")
            backup_command = 'netsh advfirewall set allprofiles firewallpolicy blockinbound,allowoutbound'
            backup_success, _ = self.run_command(backup_command)
            if backup_success:
                self.logger.info("Fallback recovery succeeded")
                return True
            else:
                self.logger.error("Firewall recovery failed")
                return False
                
    def auto_recovery(self):
        """Auto-recovery: reset firewall after consecutive failures"""
        self.logger.warning(f"Detected {self.failed_attempts} consecutive polling failures, starting auto-recovery")
        self.logger.info(f"Waiting {self.recovery_wait_time} seconds before firewall reset...")
        
        # 等待指定时间
        for i in range(self.recovery_wait_time):
            time.sleep(1)
            # Log every minute while waiting
            if (i + 1) % 60 == 0:
                remaining_minutes = (self.recovery_wait_time - i - 1) // 60
                self.logger.info(f"Auto-recovery countdown: {remaining_minutes} minutes remaining")
        
        self.logger.info("Running auto-recovery now...")
        
        # 重置防火墙
        reset_success = self.restore_original_firewall_policy()
        
        if reset_success:
            # Reset succeeded; clear state and counters
            self.blocked = False
            self.failed_attempts = 0
            self.logger.info("Auto-recovery complete; network restored; resuming polling")
        else:
            # Reset failed; still clear counters to avoid loops
            self.failed_attempts = 0
            self.logger.error("Auto-recovery failed; will continue polling")
            
        return reset_success
        
    def create_block_rules(self):
        """Create blocking rules"""
        if self.blocked:
            self.logger.info("Network already blocked; skip creating rules")
            return True
            
        self.logger.info("Creating network blocking rules...")
        
        # Remove possible stale rules first
        self.remove_block_rules()
        
        # Save current firewall outbound default policy first
        self.save_original_firewall_policy()
        
        # Set firewall default policy to block outbound
        policy_command = 'netsh advfirewall set allprofiles firewallpolicy blockinbound,blockoutbound'
        policy_success, _ = self.run_command(policy_command)
        
        if policy_success:
            # Exceptions: allow this program and essential endpoints
            
            # Allow DNS first (needed before name resolution)
            dns_command = (
                f'netsh advfirewall firewall add rule '
                f'name="NetworkController_Allow_DNS" '
                f'dir=out action=allow protocol=UDP '
                f'remoteport=53 '
                f'profile=any enable=yes'
            )
            self.run_command(dns_command)
            
            # Allow access to powerlean.github.io (HTTP and HTTPS)
            allow_domain_http = (
                f'netsh advfirewall firewall add rule '
                f'name="NetworkController_Allow_Powerlean_HTTP" '
                f'dir=out action=allow protocol=TCP '
                f'remoteport=80 '
                f'program="{sys.executable}" '
                f'profile=any enable=yes'
            )
            self.run_command(allow_domain_http)
            
            allow_domain_https = (
                f'netsh advfirewall firewall add rule '
                f'name="NetworkController_Allow_Powerlean_HTTPS" '
                f'dir=out action=allow protocol=TCP '
                f'remoteport=443 '
                f'program="{sys.executable}" '
                f'profile=any enable=yes'
            )
            self.run_command(allow_domain_https)
            
            # Allow all outbound for this program (ensure the controller works)
            allow_program = (
                f'netsh advfirewall firewall add rule '
                f'name="NetworkController_Allow_Program" '
                f'dir=out action=allow '
                f'program="{sys.executable}" '
                f'profile=any enable=yes'
            )
            self.run_command(allow_program)
            
            # Allow loopback
            loopback_command = (
                f'netsh advfirewall firewall add rule '
                f'name="NetworkController_Allow_Loopback" '
                f'dir=out action=allow '
                f'remoteip=127.0.0.1 '
                f'profile=any enable=yes'
            )
            self.run_command(loopback_command)
            
            # Allow DHCP client traffic (keep network connectivity)
            dhcp_command = (
                f'netsh advfirewall firewall add rule '
                f'name="NetworkController_Allow_DHCP" '
                f'dir=out action=allow protocol=UDP '
                f'localport=68 remoteport=67 '
                f'profile=any enable=yes'
            )
            self.run_command(dhcp_command)
            
            self.blocked = True
            self.logger.info("Network blocking rules created successfully")
            return True
        else:
            self.logger.error("Failed to set firewall policy")
            return False
            
    def remove_block_rules(self):
        """Remove blocking rules"""
        if not self.blocked:
            self.logger.info("Network not blocked; skip removal")
            return True
            
        self.logger.info("Removing network blocking rules...")
        
        # Use firewall reset to restore network access
        # netsh advfirewall reset clears all custom rules and restores defaults
        policy_restored = self.restore_original_firewall_policy()
        
        if policy_restored:
            self.blocked = False
            self.logger.info("Firewall reset; network access restored")
            
            # Extra network refresh to ensure restoration applies
            self.logger.info("Refreshing network configuration to ensure restoration applies...")
            self.run_command('ipconfig /flushdns >nul 2>&1')
            self.run_command('gpupdate /force >nul 2>&1')
            
            return True
        else:
            self.logger.error("Firewall reset failed")
            # 即使出现错误也标记为未阻止，避免状态不一致
            self.blocked = False
            return False
            
    def fetch_remote_config(self):
        """Fetch remote configuration"""
        try:
            self.logger.debug(f"Fetching remote config: {self.url}")
            
            # 设置请求超时和重试
            response = requests.get(
                self.url, 
                timeout=10,
                headers={
                    'User-Agent': 'NetworkController/1.0',
                    'Accept': 'text/plain'
                }
            )
            response.raise_for_status()
            
            content = response.text.strip()
            self.logger.debug(f"Remote config content: '{content}'")
            return content
            
        except requests.exceptions.RequestException as e:
            error_msg = str(e)
            self.logger.error(f"Failed to fetch remote config: {error_msg}")
            
            # Detect if access is blocked by firewall
            if "WinError 10013" in error_msg and self.blocked:
                self.logger.warning("Detected controller network blocked; firewall rules may be misconfigured")
                self.logger.info("Consider checking firewall rules or using the recovery tool")
            
            # 增加失败计数（用于自动恢复机制）
            self.failed_attempts += 1
            return None
        except Exception as e:
            self.logger.error(f"Unknown error while fetching remote config: {str(e)}")
            # 增加失败计数
            self.failed_attempts += 1
            return None

    # -------------------- Auto-update logic --------------------
    def _read_local_version(self) -> int:
        try:
            if not os.path.exists(self.local_version_file):
                return 0
            with open(self.local_version_file, 'r', encoding='utf-8') as f:
                txt = f.read().strip()
                return int(txt) if txt.isdigit() else 0
        except Exception as e:
            self.logger.error(f"Failed to read local version: {str(e)}")
            return 0

    def _fetch_remote_version(self) -> int:
        try:
            r = requests.get(self.update_version_url, timeout=10, headers={
                'User-Agent': 'NetworkController/1.0',
                'Accept': 'text/plain'
            })
            r.raise_for_status()
            txt = r.text.strip()
            if txt.isdigit():
                return int(txt)
            self.logger.warning(f"Remote version value is not numeric: '{txt}'")
            return -1
        except Exception as e:
            self.logger.error(f"Failed to fetch remote version: {str(e)}")
            return -1

    def _write_local_version(self, version: int) -> None:
        try:
            with open(self.local_version_file, 'w', encoding='utf-8') as f:
                f.write(str(version))
        except Exception as e:
            self.logger.error(f"Failed to write local version: {str(e)}")

    def _schedule_update_apply(self, zip_path: str, remote_version: int) -> None:
        """Create and launch a detached updater batch to stop service, extract and overlay, write version, and restart service."""
        base_dir = os.path.dirname(os.path.abspath(__file__))
        temp_dir = tempfile.mkdtemp(prefix="netupd_")
        extract_dir = os.path.join(temp_dir, "extract")
        os.makedirs(extract_dir, exist_ok=True)

        # Prepare updater batch
        updater_bat = os.path.join(temp_dir, "apply_update.bat")
        bat_lines = [
            "@echo off",
            "chcp 65001 >nul",
            f"set \"BASE_DIR={base_dir}\"",
            f"set \"ZIP={zip_path}\"",
            f"set \"EXTRACT_DIR={extract_dir}\"",
            f"set \"NEW_VER={remote_version}\"",
            "echo Stopping service...",
            "sc stop NetworkControllerService >nul 2>&1",
            "for /l %%i in (1,1,60) do (",
            "  sc query NetworkControllerService | find \"STOPPED\" >nul && goto :stopped",
            "  timeout /t 1 /nobreak >nul",
            ")",
            ":stopped",
            "echo Extracting update...",
            "powershell -Command \"Expand-Archive -Path '%ZIP%' -DestinationPath '%EXTRACT_DIR%' -Force\"",
            "echo Copying files...",
            "if exist \"%EXTRACT_DIR%\\WindowsNET\\WindowsNET\" (",
            "  robocopy \"%EXTRACT_DIR%\\WindowsNET\\WindowsNET\" \"%BASE_DIR%\" /E /NFL /NDL /NJH /NJS /NP >nul",
            ") else (",
            "  robocopy \"%EXTRACT_DIR%\" \"%BASE_DIR%\" /E /NFL /NDL /NJH /NJS /NP >nul",
            ")",
            "echo Updating local version...",
            "echo %NEW_VER%> \"%BASE_DIR%\\block_ver.txt\"",
            "echo Starting service...",
            "sc start NetworkControllerService >nul 2>&1",
            "exit /b 0",
        ]
        try:
            with open(updater_bat, 'w', encoding='utf-8') as f:
                f.write("\r\n".join(bat_lines))
        except Exception as e:
            self.logger.error(f"Failed to prepare updater script: {str(e)}")
            return

        # Launch updater detached (do not wait)
        try:
            cmd = f'start "" cmd /c "\"{updater_bat}\""'
            self.logger.info("Launching updater...")
            subprocess.Popen(cmd, shell=True)
        except Exception as e:
            self.logger.error(f"Failed to launch updater: {str(e)}")

    def _download_update_zip(self) -> str:
        """Download update zip to a temp file; return path or empty string on failure."""
        try:
            self.logger.info("Downloading update package...")
            r = requests.get(self.update_zip_url, timeout=30, stream=True, headers={
                'User-Agent': 'NetworkController/1.0'
            })
            r.raise_for_status()
            fd, tmp_path = tempfile.mkstemp(prefix="netupd_", suffix=".zip")
            with os.fdopen(fd, 'wb') as f:
                for chunk in r.iter_content(chunk_size=1024 * 256):
                    if chunk:
                        f.write(chunk)
            self.logger.info(f"Update downloaded: {tmp_path}")
            return tmp_path
        except Exception as e:
            self.logger.error(f"Failed to download update: {str(e)}")
            return ""

    def maybe_check_update(self):
        now = time.time()
        if now - self._last_update_check_ts < self.update_check_interval:
            return
        self._last_update_check_ts = now

        self.logger.debug("Checking for updates...")
        remote_ver = self._fetch_remote_version()
        if remote_ver < 0:
            return
        local_ver = self._read_local_version()
        if remote_ver == local_ver:
            self.logger.debug("No update available (versions match)")
            return

        self.logger.info(f"Update available: remote={remote_ver}, local={local_ver}")
        zip_path = self._download_update_zip()
        if not zip_path:
            return
        # Schedule apply and let updater manage stop/copy/start
        self._schedule_update_apply(zip_path, remote_ver)
 
    def process_config(self, config_content):
        """Process configuration content"""
        if config_content is None:
            self.logger.warning("Config content is empty; keeping current state")
            return
        
        # Reset failure counter when config is fetched successfully
        self.failed_attempts = 0
            
        if config_content.lower() == "block":
            self.logger.info("Remote config requests blocking network access")
            if not self.blocked:
                self.create_block_rules()
            else:
                self.logger.info("Network already blocked; no action needed")
        elif config_content.lower() == "stuck":
            self.logger.info("Remote config requests brief block (stuck mode): block 4s then restore, then wait 2s")
            # Ensure network is blocked (idempotent if already blocked)
            self.create_block_rules()
            time.sleep(4)
            # Restore network
            self.remove_block_rules()
            # Extra wait as requested
            time.sleep(2)
        elif config_content == "" or config_content.lower() == "allow":
            self.logger.info("Remote config requests restoring network access")
            if self.blocked:
                self.remove_block_rules()
            else:
                self.logger.info("Network not blocked; no restoration needed")
        else:
            self.logger.warning(f"Unknown config content: '{config_content}', keeping current state")
            
    def cleanup_on_exit(self):
        """Cleanup work when program exits"""
        self.logger.info("Exiting; cleaning up firewall rules...")
        self.remove_block_rules()
        
    def run(self):
        """Main run loop"""
        self.logger.info("Network control service started")
        self.logger.info(f"Polling URL: {self.url}")
        self.logger.info(f"Polling interval: {self.poll_interval}s")
        
        try:
            while True:
                try:
                    # Periodic update check
                    self.maybe_check_update()
                    # Auto-recovery if needed
                    if self.failed_attempts >= self.max_failed_attempts and self.blocked:
                        self.auto_recovery()
 
                    # Fetch remote config
                    config_content = self.fetch_remote_config()
 
                    # Process config
                    self.process_config(config_content)
 
                    # Wait until next poll
                    time.sleep(self.poll_interval)
 
                except KeyboardInterrupt:
                    self.logger.info("Received interrupt; exiting...")
                    break
                except Exception as e:
                    self.logger.error(f"Error in run loop: {str(e)}")
                    time.sleep(self.poll_interval)  # avoid tight loop on errors
 
        except Exception as e:
            self.logger.error(f"Critical error during run: {str(e)}")
        finally:
            self.cleanup_on_exit()
            self.logger.info("Network control service stopped")

def main():
    """Main entry point"""
    # Check administrator privileges
    try:
        # Try a command requiring admin privilege to check elevation
        result = subprocess.run(
            'netsh advfirewall show allprofiles', 
            shell=True, 
            capture_output=True, 
            text=True
        )
        if result.returncode != 0:
            print("Error: Administrator privileges are required to run this program")
            print("Please re-run this program as Administrator")
            sys.exit(1)
    except Exception:
        print("Error: Failed to check administrator privileges")
        sys.exit(1)
    
    # Create and run controller
    controller = NetworkController()
    controller.run()

if __name__ == "__main__":
    main()
