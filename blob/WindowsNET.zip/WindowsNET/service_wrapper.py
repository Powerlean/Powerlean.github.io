#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Windows Service wrapper
Wraps the network controller as a Windows Service for background run and
auto-start on boot.
"""

import win32serviceutil
import win32service
import win32event
import servicemanager
import logging
import sys
import os
import time
from network_controller import NetworkController

class NetworkControllerService(win32serviceutil.ServiceFramework):
    """Windows service for network controller"""
    
    _svc_name_ = "NetworkControllerService"
    _svc_display_name_ = "Network Controller Service"
    _svc_description_ = "Background service that monitors remote config and controls network access"
    
    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)
        self.controller = None
        self.running = True
        
        # Configure service logging
        self.setup_service_logging()
        
    def setup_service_logging(self):
        """Configure service logging"""
        try:
            # Service directory
            service_dir = os.path.dirname(os.path.abspath(__file__))
            log_dir = os.path.join(service_dir, "logs")
            
            if not os.path.exists(log_dir):
                os.makedirs(log_dir)
                
            log_file = os.path.join(log_dir, "service.log")
            
            logging.basicConfig(
                level=logging.INFO,
                format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                handlers=[
                    logging.FileHandler(log_file, encoding='utf-8'),
                ]
            )
            
            self.logger = logging.getLogger('NetworkControllerService')
            
        except Exception as e:
            # If logging setup fails, use Windows Event Log
            servicemanager.LogErrorMsg(f"Failed to setup logging: {str(e)}")
            
    def SvcStop(self):
        """Stop service"""
        try:
            self.logger.info("Received stop request")
            self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
            self.running = False
            
            # Stop controller
            if self.controller:
                self.controller.cleanup_on_exit()
                
            win32event.SetEvent(self.hWaitStop)
            self.logger.info("Service stopped")
            
        except Exception as e:
            error_msg = f"Error while stopping service: {str(e)}"
            self.logger.error(error_msg)
            servicemanager.LogErrorMsg(error_msg)
            
    def SvcDoRun(self):
        """Run service"""
        try:
            # Log service start
            self.logger.info("Network controller service starting...")
            servicemanager.LogMsg(
                servicemanager.EVENTLOG_INFORMATION_TYPE,
                servicemanager.PYS_SERVICE_STARTED,
                (self._svc_name_, '')
            )
            
            # Create controller instance
            self.controller = NetworkController()
            
            # Run controller in a separate thread
            import threading
            controller_thread = threading.Thread(target=self.run_controller)
            controller_thread.daemon = True
            controller_thread.start()
            
            # Wait for stop signal
            while self.running:
                rc = win32event.WaitForSingleObject(self.hWaitStop, 1000)
                if rc == win32event.WAIT_OBJECT_0:
                    # Stop signal received
                    break
                    
            self.logger.info("Network controller service stopped")
            
        except Exception as e:
            error_msg = f"Error while running service: {str(e)}"
            self.logger.error(error_msg)
            servicemanager.LogErrorMsg(error_msg)
            
    def run_controller(self):
        """Run network controller"""
        try:
            self.logger.info("Network controller running")
            
            while self.running:
                try:
                    # Auto-recovery if needed
                    if (self.controller.failed_attempts >= self.controller.max_failed_attempts 
                        and self.controller.blocked):
                        # Run auto-recovery in service environment
                        self.logger.info("Service detected auto-recovery needed")
                        self.controller.auto_recovery()
                    
                    # Fetch config
                    config_content = self.controller.fetch_remote_config()
                    
                    # Process config
                    self.controller.process_config(config_content)
                    
                    # Wait until next poll (support interruption)
                    for _ in range(self.controller.poll_interval):
                        if not self.running:
                            break
                        time.sleep(1)
                        
                except Exception as e:
                    self.logger.error(f"Error inside controller loop: {str(e)}")
                    # Wait a while and continue on errors
                    for _ in range(self.controller.poll_interval):
                        if not self.running:
                            break
                        time.sleep(1)
                        
        except Exception as e:
            error_msg = f"Critical error while running controller: {str(e)}"
            self.logger.error(error_msg)
            servicemanager.LogErrorMsg(error_msg)

def main():
    """Main - handle service install/start operations"""
    if len(sys.argv) == 1:
        # Run as a service
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(NetworkControllerService)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        # Handle command line
        win32serviceutil.HandleCommandLine(NetworkControllerService)

if __name__ == '__main__':
    main()
